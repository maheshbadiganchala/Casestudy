package casestudy;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface AdminRepositery extends MongoRepository<Admin, String> {

}
